document.addEventListener("DOMContentLoaded", () => {
    console.log("Online Examination Platform Loaded");
});
